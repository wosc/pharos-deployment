require File.dirname(__FILE__) + '/../test_helper'
require 'mailbox_controller'

# Re-raise errors caught by the controller.
class MailboxController; def rescue_action(e) raise e end; end

class MailboxControllerTest < Test::Unit::TestCase
    fixtures :mailboxes, :domains, :users

    def setup
        @controller = MailboxController.new
        @request    = ActionController::TestRequest.new
        @response   = ActionController::TestResponse.new

        @request.session[:user] = users(:mailuser)
        @domain = users(:mailuser).domains.first.name
    end

    def test_users_sees_own
        get :list, :domain => @domain

        mailboxes = assigns(:mailboxes)
        assert_not_nil mailboxes
        assert_equal 1, mailboxes.size
        assert_equal "box", mailboxes.first.local_part
    end

# XXX: validations missing
#     def test_create
#         num_mailboxes = Mailbox.count

#         post :create, :mailbox => {}, :domain => @domain

#         assert_response :redirect
#         assert_redirected_to :action => 'list'

#         assert_equal num_mailboxes + 1, Mailbox.count
#     end

    def test_edit
        get :edit, :id => 1, :domain => @domain

        assert_response :success
        assert_template 'edit'

        assert_not_nil assigns(:mailbox)
        assert assigns(:mailbox).valid?
    end

    def test_update
        post :update, :id => 1, :domain => @domain
        assert_response :redirect
        assert_redirected_to :action => ''
    end

    def test_delete
        assert_not_nil Mailbox.find(1)

        post :delete, :id => 1, :domain => @domain
        assert_response :redirect
        assert_redirected_to :action => ''

        assert_raise(ActiveRecord::RecordNotFound) {
            Mailbox.find(1)
        }
    end
end
