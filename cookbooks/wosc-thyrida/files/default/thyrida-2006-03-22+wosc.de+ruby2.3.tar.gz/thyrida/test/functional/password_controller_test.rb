require File.dirname(__FILE__) + '/../test_helper'
require 'password_controller'

# Re-raise errors caught by the controller.
class PasswordController; def rescue_action(e) raise e end; end

class PasswordControllerTest < Test::Unit::TestCase

  fixtures :mailboxes

  def setup
    @controller = PasswordController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
  end

  def test_form
      get :index
      assert_match /Email address/, @response.body
  end


  def test_change
      post :password_action, :mailbox => { "login" => "test@example.com",
                                           "current_password" => "test",
                                           "password" => "foo",
                                           "password_confirmation" => "foo" }
      assert_redirected_to :action => "password"
      puts @response.session.inspect

      mailboxes(:test).reload
      assert_equal "ash/3bldtbcqc", mailboxes(:test).password
  end


  def test_nonexistant_mailbox_shold_fail
      post :password_action, :mailbox => { "login" => "doesnotexist" }
      assert_response 200
      assert_match /unknown email address/, @response.body
  end
end
