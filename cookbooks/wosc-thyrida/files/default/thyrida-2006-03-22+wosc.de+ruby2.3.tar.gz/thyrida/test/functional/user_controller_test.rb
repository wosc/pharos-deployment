require File.dirname(__FILE__) + '/../test_helper'
require 'user_controller'

# Raise errors beyond the default web-based presentation
class UserController; def rescue_action(e) raise e end; end

class UserControllerTest < Test::Unit::TestCase
  
  fixtures :users
    
  def setup
    @controller = UserController.new
    @request, @response = ActionController::TestRequest.new, ActionController::TestResponse.new
    @request.host = "localhost"
  end
  
  def test_auth_bob
    @request.session[:return_to] = "/bogus/location"

    post :login, :login => "bob", :password => "test"
    assert_session_has :user

    assert_equal users(:bob), @response.session[:user]
    
    assert_redirected_to "/bogus/location"
  end

  def test_invalid_login
    post :login, :login => "bob", :password => "not_correct"
     
    assert_session_has_no :user
    
    assert_template_has "login"
  end
  
  def test_login_logoff

    post :login, :login => "bob", :password => "test"
    assert_session_has :user

    get :logout
    assert_session_has_no :user

  end
  
end
