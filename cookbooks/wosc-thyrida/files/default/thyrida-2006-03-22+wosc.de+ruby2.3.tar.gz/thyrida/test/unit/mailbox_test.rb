require File.dirname(__FILE__) + '/../test_helper'

class MailboxTest < Test::Unit::TestCase
  fixtures :mailboxes, :domains

  def test_forward
      m = mailboxes(:test)
      m.forward = "forward@example.com"
      assert m.save
      assert_equal m.forward, m.action
      assert_nil m.dotted_address
  end

  def test_mailbox
      m = mailboxes(:test)
      m.has_mailbox = true
      m.forward = ""
      assert m.save
      assert_equal "mb-test.example.com", m.action
      assert_equal "test.example.com", m.dotted_address

      m.forward = "forward@example.com, another@example.com"
      assert m.save
      assert_equal m.forward + ", mb-test.example.com", m.action
  end

  def test_vacation
      m = mailboxes(:test)
      m.has_vacation = true
      assert m.save
      assert_equal "vacation-1", m.action

      m.has_mailbox = true
      assert m.save
      assert_equal "mb-test.example.com, vacation-1", m.action

      m.forward = "forward@example.com"
      assert m.save
      assert_equal m.forward + ", mb-test.example.com, vacation-1", m.action
  end

  def test_login
      m = mailboxes(:test)
      assert m.save
      assert_equal "test@example.com", m.login
  end

  def test_mailbox_path
      m = mailboxes(:test)
      m.has_mailbox = true
      assert m.save
      assert_equal "/var/mail/test.example.com", m.mailbox_path
  end

  def test_crypt
      m = mailboxes(:test)
      m.password = m.password_confirmation = "mypassword"
      assert m.save
      assert_equal "asWJj7TrAfarg", m.password
  end

  def test_validation
      m = mailboxes(:test)
      m.local_part = "some_valid.local-part"
      assert m.save
    
      m.local_part = "*"
      assert m.save

      m.local_part = "something.*"
      assert ! m.save
  end

  def test_confirmation
    ActionMailer::Base.delivery_method = :test
    ActionMailer::Base.perform_deliveries = true
    ActionMailer::Base.deliveries = emails = []

    m = Mailbox.new
    m.domain = domains(:example)
    m.local_part = "test1"
    m.password = "test"
    m.password_confirmation = "test"
    m.has_mailbox = true
    
    assert m.save
    assert_match /abgeschlossen/, emails[0].subject
    emails.delete_at(0)

    m.has_vacation = true
    m.password_confirmation = nil
    assert m.save
    assert_match /Konfiguration/, emails[0].subject
  end
end
