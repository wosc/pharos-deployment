#!/usr/bin/ruby

class Main
    require "dbi"

    def initialize()
        @db = DBI.connect("dbi:Mysql:host=localhost;database=ii-tech", "ii-tech", "uhland5")
    end

    def convert_users()
        result = []
        @db.select_all("SELECT * FROM admins") do |row|
            case row["group"]
            when 2: role = "root"
            when 1: role = "mail"
            when 0: role = "awstats"
            end
            
            result << "INSERT INTO users (id, login, password, role) " \
            + %{VALUES (#{row["id"]}, "#{row["login"]}", "#{row["password"]}", "#{role}");}
        end

        return result
    end

    def convert_domains()
        result = []
        @db.select_all("SELECT * FROM domains") do |row|
            
            result << "INSERT INTO domains (id, name, user_id, customer, responsible, price_plan, registry, state, since, last_payment, payment_until, comments) " \
            + %{VALUES (#{row["id"]}, "#{row["domain"]}", #{row["admin"]}, "#{row["customer"]}", "#{row["responsible"]}", "#{row["price_plan"]}", } \
            + %{"#{row["registry"]}", "#{row["state"]}", "#{row["since"]}", "#{row["last_payment"]}", "#{row["paidfor_until"]}", "#{row["comments"]}");}
        end

        return result
    end

    def convert_mailboxes()
        result = []
        @db.select_all("SELECT * FROM mailboxes") do |row|

            has_mailbox = 0
            forwards = []
            dotted = ""
            row["action"].split(", ").each do |action|
                if action.include?("mb-")
                    has_mailbox = 1
                    dotted = row["login"].sub("@", ".")
                else
                    forwards << action
                end
            end
            forward = forwards.join(", ")

            has_spamfilter = row["spamfilter"] == "Y" ? 1 : 0

            # vacation
            has_vacation = 0
            vacation_subject = ""
            vacation_body = ""
            if vac = @db.select_one("SELECT * FROM vacation WHERE id=#{row["id"]}")
                has_vacation = 1
                vacation_subject = vac["subject"]
                vacation_body = vac["body"]
            end

            result << "INSERT INTO mailboxes (id, domain_id, local_part, dotted_address, login, password, forward, has_mailbox, has_spamfilter, has_vacation, " \
            + "vacation_subject, vacation_body, action, mailbox_path)" \
            + %{VALUES (#{row["id"]}, "#{row["domain"]}", "#{row["local_part"]}", "#{dotted}", "#{row["login"]}", "#{row["password"]}", } \
            + %{"#{forward}", #{has_mailbox}, #{has_spamfilter}, #{has_vacation}, "#{vacation_subject}", "#{vacation_body}", "#{row["action"]}", "#{row["mailbox"]}");}
        end

        return result
    end
    
    def run(argv)
        result = []
        result << convert_users
        result << convert_domains
        result << convert_mailboxes

        puts result.join("\n")
    end
end

Main.new.run(ARGV)
