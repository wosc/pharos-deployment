class AddDomainTable < ActiveRecord::Migration
  def self.up
      create_table :domains do |table|
          table.column :name, :string, :null => false
          table.column :user_id, :integer, :null => false

          table.column :customer, :string
          table.column :responsible, :string, :default => "ii-tech"
          table.column :price_plan, :string, :default => "special"
          table.column :registry, :string, :default => "Providerdomain"

          table.column :state, :string, :default => "OK"

          table.column :since, :date, :default => "0000-00-00"
          table.column :last_payment, :date, :default => "0000-00-00"
          table.column :payment_until, :date, :default => "0000-00-00"

          table.column :comments, :text
      end
  end

  def self.down
      drop_table :domains
  end
end
