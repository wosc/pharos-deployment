class AddMailboxTable < ActiveRecord::Migration
  def self.up
      create_table :mailboxes do |table|
          table.column :domain_id, :integer, :null => false
          table.column :local_part, :string, :limit => 50, :null => false
          table.column :dotted_address, :string

          table.column :login, :string, :null => false
          table.column :password, :string, :limit => 50, :null => false

          table.column :forward, :string
          table.column :has_mailbox, :boolean, :null => false, :default => false
          table.column :has_vacation, :boolean, :null => false, :default => false
          table.column :has_spamfilter, :boolean, :null => false, :default => false

          table.column :vacation_subject, :string
          table.column :vacation_body, :text

          # internal
          # used by exim
          table.column :action, :string, :null => false
          # used by exim+courier
          table.column :mailbox_path, :string, :null => false

          # used by courier
          table.column :uid, :integer, :null => false, :default => 105
          table.column :gid, :integer, :null => false, :default => 8
      end
  end

  def self.down
      drop_table :mailboxes
  end
end
