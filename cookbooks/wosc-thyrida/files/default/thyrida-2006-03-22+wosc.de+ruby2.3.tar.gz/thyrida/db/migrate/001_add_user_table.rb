class AddUserTable < ActiveRecord::Migration
  def self.up
      create_table :users do |table|
          table.column :login,  :string, :limit => 40, :null => false
          table.column :password, :string, :limit => 40, :null => false
          # supported roles are "root", "mail", "awstats"
          table.column :role, :string, :null => false, :default => "mail"
      end

      User.create(:login => "root", :password => "root", :password_confirmation => "root", :role => "root")
  end

  def self.down
      drop_table :users
  end
end
