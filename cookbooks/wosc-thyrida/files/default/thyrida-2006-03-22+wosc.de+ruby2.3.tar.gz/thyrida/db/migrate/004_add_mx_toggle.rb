class AddMxToggle < ActiveRecord::Migration
  def self.up
    add_column :domains, :is_mx, :boolean, :null => false, :default => true
  end

  def self.down
    remove_column :domains, :is_mx
  end
end
