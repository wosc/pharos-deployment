module DomainsHelper
end
