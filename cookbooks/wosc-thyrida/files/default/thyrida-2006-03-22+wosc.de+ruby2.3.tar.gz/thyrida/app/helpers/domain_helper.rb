module DomainHelper
end
