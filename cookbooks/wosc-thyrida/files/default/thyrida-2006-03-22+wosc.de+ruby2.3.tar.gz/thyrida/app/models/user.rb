class User < ActiveRecord::Base
  ROLE = ["root", "mail", "awstats"]

  has_many :domains

  def authenticate(user_password)
    if user_password.crypt(self.password) == self.password
        return self
    else
        return nil
    end
  end  

  def root?
      role == "root"
  end

  acts_as_password
  validates_length_of :password, :within => 3..40, :if => Proc.new { |user| user.password != "" }
  attr_accessor :current_password # when changing the password
  
  validates_presence_of :login
  validates_length_of :login, :within => 2..40
  validates_uniqueness_of :login, :on => :create

  validates_inclusion_of :role, :in => ROLE
end
