class Domain < ActiveRecord::Base
    REGISTRY = ["Providerdomain", "Freeparking", "Strato", "Hostroute", "Unknown"]
    PRICE_PLAN = ["Bronze", "Bronze 50%", "Silver", "Silver 50%", "Gold", "Gold 50%", "special", "ii-tech", "cdfz", "matze", "wosc"]
    RESPONSIBLE = ["cdfz", "matze", "wosc", "ii-tech"]
    STATE = ["OK", "Gekuendigt", "Warten"]

    belongs_to :user
    has_many :mailboxes

    validates_presence_of :name, :user

    def alias_for
        begin
            File.open("/etc/exim4/domain-aliases") do |file|
                file.each_line do |line|
                    line.strip!
                    next if line[0, 1] == "#"
                    if line =~ /#{self.name} *: *([a-z.]+)/ then return $1 end
                end
            end
        rescue SystemCallError
            return false
        end
        return nil
    end
end
