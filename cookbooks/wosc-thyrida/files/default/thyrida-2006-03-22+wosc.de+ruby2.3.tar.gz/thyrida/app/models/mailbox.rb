class Mailbox < ActiveRecord::Base
    belongs_to :domain

    before_save :generate_action, :generate_login, :generate_path, :generate_dotted
    # after_create :confirm_create
    # after_save :confirm_save

    def confirm_create
        Notifier.deliver_mailbox_confirmation(self, :create) if has_mailbox
    end

    def confirm_save
        Notifier.deliver_mailbox_confirmation(self, :save) if has_mailbox
    end

    def generate_action
        actions = []
        actions << forward if !forward.blank?
        actions << "mb-#{local_part}.#{domain.name}" if has_mailbox
        actions << "vacation-#{self.id}" if has_vacation
        self.action = actions.join(", ")
    end

    def generate_login
        self.login = "#{local_part}@#{domain.name}"
    end

    def generate_path
        self.mailbox_path = has_mailbox ? "/var/mail/#{local_part}.#{domain.name}" : ""
    end

    def generate_dotted
        self.dotted_address = has_mailbox ? "#{local_part}.#{domain.name}" : nil
    end

    validates_presence_of :local_part
    validates_uniqueness_of :local_part, :scope => "domain_id"
    validates_format_of :local_part, :with => /^([-.0-9A-Z_]+|\*)$/i

    def validate
        if !has_mailbox && forward == ""
            errors.add_to_base("Please specify either local mailbox or a forward")
        end
    end

    acts_as_password
    validates_length_of :password, :within => 3..40, :if => Proc.new { |mb| mb.password != "" }
    attr_accessor :current_password # when changing the password

    def authenticate(user_password)
        user_password.crypt(self.password) == self.password
    end  
 end
