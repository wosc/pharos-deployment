class Notifier < ActionMailer::Base
    def mailbox_confirmation(mailbox, reason)
        if reason == :create
          sub = "Einrichtung des Email-Accounts abgeschlossen"
        else
          sub = "Konfiguration des Email-Accounts aktualisiert"
        end

        recipients mailbox.local_part + "@" + mailbox.domain.name
        subject sub
        from "wosc.de Emailkonfiguration <wosc@wosc.de>"
        body({ "mailbox" => mailbox })
    end
end
