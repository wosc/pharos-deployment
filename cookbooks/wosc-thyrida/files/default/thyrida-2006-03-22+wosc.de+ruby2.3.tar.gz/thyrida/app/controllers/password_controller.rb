class PasswordController < ApplicationController
    layout "empty"


    def protect?(action)
        false
    end


    def index
        password
        render :action => 'password'
    end


    def password
        @mailbox = Mailbox.new
    end


    def password_action
        @mailbox = Mailbox.find_by_login(params[:mailbox][:login])
        if @mailbox == nil
          @mailbox = Mailbox.new
          @mailbox.attributes = params[:mailbox]
          @mailbox.errors.add("login", "for an unknown email address")
          render :action => 'password'
          return
        end

        @clone = @mailbox.clone
        @mailbox.attributes = params[:mailbox]

        if @clone.authenticate(@mailbox.current_password)
            if @mailbox.password == ""
                @mailbox.errors.add("password", "cannot be blank")
            else
                @mailbox.save
            end
        else
            @mailbox.errors.add("current_password", "incorrect")
        end

        if @mailbox.errors.empty?
            flash[:notice] = 'Password was successfully updated.'
            redirect_to :action => 'password'
        else
            render :action => 'password'
        end
    end
end
