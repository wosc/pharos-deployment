require "time"

class MailboxController < ApplicationController
    def authorize?(user)
        return true if user.role == "root"
        return true if action_name == "index" && !params[:domain]

        domain = Domain.find_by_name(params[:domain])
        domain.user == user
    end

    def index
        if !params[:domain]
            if !@USER.root? && domain = @USER.domains.find(:first) 
                redirect_to :domain => domain.name
            end
        else
            list
            render :action => "list"
        end
    end

    def list
        @domain = Domain.find_by_name(params[:domain])
        @mailboxes = Mailbox.find_all_by_domain_id(@domain.id, :order => "local_part")
    end

    def new
        @mailbox = Mailbox.new
        @mailbox.domain = Domain.find_by_name(params[:domain])
    end

    def create
        @mailbox = Mailbox.new(params[:mailbox])
        if @mailbox.save
            flash[:notice] = 'Mailbox was successfully created.'
            redirect_to :controller => 'mailbox', :action => ""
        else
            render :action => 'new'
        end
    end

    def edit
        @mailbox = Mailbox.find(params[:id])
    end

    def update
        @mailbox = Mailbox.find(params[:id])
        if @mailbox.update_attributes(params[:mailbox])
            flash[:notice] = 'Mailbox was successfully updated.'
            redirect_to :controller => 'mailbox', :action => ""
        else
            render :action => 'edit'
        end
    end

    def delete
        @mailbox = Mailbox.find(params[:id])
        if @mailbox.has_mailbox
            begin
                File.open("/var/www/ii-tech/archon/internal/deleted-mailboxes.txt", "a+") do |file|
                    file.print("#{@mailbox.dotted_address} #{Time.new}\n")
                end
            rescue
            end
        end

        @mailbox.destroy
        redirect_to :controller => 'mailbox', :action => ""
    end
end
