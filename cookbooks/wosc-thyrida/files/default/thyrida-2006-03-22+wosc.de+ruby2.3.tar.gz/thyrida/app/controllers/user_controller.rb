class UserController < ApplicationController
    layout :choose_layout

    def choose_layout
        action_name == "login" ? "empty" : "default"
    end

    def protect?(action)
        action != "login"
    end

    def authorize?(user)
        user.role == "root" || ["login", "logout", "password", "password_action"].include?(action_name)
    end

    def login
        case @request.method
        when :post
            user = User.find_by_login(@params[:login])
            if user && @session[:user] = user.authenticate(@params[:password])
                if @session[:user].root?
                    redirect_back_or_default :controller => "domain"
                else
                    redirect_back_or_default :controller => "mailbox"
                end
            else
                @login = @params[:login]
                flash.now['notice']  = "Login failed"
            end
        end
    end
    
    def logout
        @session[:user] = nil
        redirect_to :action => 'login'
    end

    def password
        @user = @USER
    end

    def password_action
        @user = User.find(@USER.id)
        @user.attributes = @params[:user]

        if @USER.authenticate(@user.current_password)
            if @user.password == ""
                @user.errors.add("password", "cannot be blank")
            else
                @user.save
            end
        else
            @user.errors.add("current_password", "incorrect")
        end

        if @user.errors.empty?
            @session[:user] = @user
            flash[:notice] = 'Password was successfully updated.'
            redirect_to :action => 'password'
        else
            render :action => 'password'
        end
    end
    
    def index
        list
        render :action => 'list'
    end

    def list
        @users = User.find_all
    end

    def new
        @user = User.new
    end

    def create
        @user = User.new(params[:user])
        if @user.save
            flash[:notice] = 'User was successfully created.'
            redirect_to :action => 'list'
        else
            render :action => 'new'
        end
    end

    def edit
        @user = User.find(params[:id])
    end

    def update
        @user = User.find(params[:id])
        if @user.update_attributes(params[:user])
            flash[:notice] = 'User was successfully updated.'
            redirect_to :action => 'list'
        else
            render :action => 'edit'
        end
    end

    def destroy
        User.find(params[:id]).destroy
        redirect_to :action => 'list'
    end
end
