require_dependency "login_system"

class ApplicationController < ActionController::Base
    layout "default"

    include LoginSystem
    before_filter :login_required, :setup

    def initialize
        @APP_VERSION = "v0.1-alpha"
    end

    def setup
        @USER = @session[:user]
        # XXX: better dummy anonymous user?
    end
end


module ActionView
  class Base
    @@field_error_proc = Proc.new{ |html_tag, instance| "<span class=\"fieldWithErrors\">#{html_tag}</span>" }
  end
end
