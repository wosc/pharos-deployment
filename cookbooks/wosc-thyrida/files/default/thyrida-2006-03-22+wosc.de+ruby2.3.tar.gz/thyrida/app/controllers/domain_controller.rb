class DomainController < ApplicationController
  def authorize?(user)
    user.role == "root"
  end

  def index
    list
    render :action => 'list'
  end

  def list
    @domains = Domain.find(:all, :order => "name")
  end

  def show
    @domain = Domain.find(params[:id])
  end

  def new
    @domain = Domain.new
  end

  def create
    @domain = Domain.new(params[:domain])
    if @domain.save
      flash[:notice] = 'Domain was successfully created.'
      redirect_to :action => 'list'
    else
      render :action => 'new'
    end
  end

  def edit
    @domain = Domain.find(params[:id])
  end

  def update
    @domain = Domain.find(params[:id])
    if @domain.update_attributes(params[:domain])
      flash[:notice] = 'Domain was successfully updated.'
      redirect_to :action => 'list'
    else
      render :action => 'edit'
    end
  end

  def destroy
    Domain.find(params[:id]).destroy
    redirect_to :action => 'list'
  end
end
